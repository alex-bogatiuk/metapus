/**
 * Common / cross-cutting types used across the frontend.
 */

/** Sort direction for list views. */
export type SortDirection = "asc" | "desc"

/** Generic sort parameters stored in URL search params. */
export interface SortParams {
    column: string | null
    direction: SortDirection
}

/** Paginated response envelope from the API. */
export interface PaginatedResponse<T> {
    items: T[]
    total: number
    page: number
    pageSize: number
}
