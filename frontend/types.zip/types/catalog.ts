/**
 * Shared types for Catalog entities.
 * Must mirror backend DTOs from the Go API.
 */

/** Base fields present in every catalog item. */
export interface BaseCatalogItem {
    id: string
    name: string
}

/** Nomenclature catalog item (справочник «Номенклатура»). */
export interface NomenclatureItem extends BaseCatalogItem {
    stock: string
    unit: string
    price: string
    sku: string
    type: string
}
