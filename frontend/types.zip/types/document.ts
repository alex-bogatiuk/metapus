/**
 * Shared types for Document entities.
 * Must mirror backend DTOs from the Go API.
 */

/** Possible document statuses. */
export type DocumentStatus = "draft" | "posted"

/** Goods Receipt document (Приходная накладная). */
export interface GoodsReceiptDoc {
    id: string
    status: DocumentStatus
    date: string
    number: string
    counterparty: string
    amount: string
    warehouse: string
    operation: string
}

/** Line item inside a Goods Receipt. */
export interface GoodsReceiptLineItem {
    id: number
    nomenclature: string
    quantity: string
    price: string
    discount: string
    amount: string
    vatRate: string
    vatAmount: string
    total: string
    comment: string
}
