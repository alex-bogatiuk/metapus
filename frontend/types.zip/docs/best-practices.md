# Metapus Frontend Guidelines

Этот документ описывает принципы разработки frontend-части проекта Metapus.
Он адаптирует архитектурные правила backend (Clean Architecture, Metadata-driven) к экосистеме Next.js / React.

---

## 1. Фундаментальные принципы

### 1.1. Code is Metadata (Frontend Edition)
UI строится на основе строгих контрактов (TypeScript interfaces), которые должны соответствовать структурам backend.
*   **Правило**: Не используйте `any` или слаботипизированные объекты.
*   **Правило**: Если backend возвращает DTO, frontend должен иметь идентичный интерфейс.

### 1.2. Explicit over Implicit
Избегайте "магии" в передаче данных и состояния.
*   **Правило**: Явно передавайте props. Избегайте глубокого prop drilling, но и не злоупотребляйте Context API для всего подряд.
*   **Правило**: Используйте URL как источник истины для состояния фильтров, пагинации и сортировки (URL-driven state).

### 1.3. Component isolation
Компоненты должны быть максимально изолированы и переиспользуемы.
*   **Правило**: UI-компоненты (`components/ui`) не должны знать о бизнес-логике.

---

## 2. Архитектура (Vertical Slices + Feature-Sliced Design)

Мы используем гибридный подход, вдохновленный FSD и Vertical Slices, адаптированный под Next.js App Router.

### Структура папок

```
frontend/
├── app/                  # Pages & Routing (Composition Root)
│   ├── (auth)/           # Route groups
│   ├── catalogs/         # Slice: Справочники
│   │   ├── [type]/       # Dynamic catalog pages
│   │   └── page.tsx      # Entry point
│   ├── documents/        # Slice: Документы
│   └── layout.tsx        # Root layout
├── components/
│   ├── ui/               # Low-level UI kit (Shadcn/ui) - DUMB
│   ├── shared/           # Shared business components (e.g., UserNav)
│   └── [feature]/        # Feature-specific components (optional)
├── lib/                  # Utilities, helpers
├── hooks/                # Global hooks
└── types/                # Global types (API DTOs, Enums)
```

### Разделение ответственности

1.  **Page Components (`/app/**/page.tsx`)**:
    *   Являются **Server Components** (по умолчанию).
    *   Отвечают за получение данных (fetch).
    *   Передают данные в клиентские компоненты.
    *   Служат "точкой сборки" для фичи.

2.  **Smart Components (Containers)**:
    *   Содержат бизнес-логику и состояние (useState, useQuery).
    *   Могут делать запросы к API (если это Client Component).
    *   Собирают Dumb-компоненты.

3.  **Dumb Components (UI)**:
    *   Только отображение (`components/ui`).
    *   Получают данные и колбэки через props.
    *   Не имеют зависимости от внешнего мира (API, Context).

---

## 3. State Management

### 3.1. Server State (React Query / SWR / fetch)
Для данных, приходящих с сервера, используйте механизмы кэширования и ревалидации.
*   В Server Components: прямой `fetch`.
*   В Client Components: `useQuery` (если нужно) или передача initial data с сервера.

### 3.2. URL State (Single Source of Truth)
Состояние списка (фильтры, сортировка, страница, поиск) **должно** храниться в URL search params.
*   Это обеспечивает workability кнопок "Назад/Вперед" и sharing ссылок.
*   Используйте хуки для синхронизации URL и состояния (например, `nuqs` или кастомные).

### 3.3. Local State
Используйте `useState` / `useReducer` только для UI-состояния (открыт/закрыт диалог, значение инпута до сабмита).

### 3.4. Global State (Zustand / Context)
Используйте крайне осторожно. Только для действительно глобальных вещей:
*   Тема (Dark/Light)
*   Данные текущего пользователя/сессии
*   Настройки приложения

---

## 4. Код и Стиль

### 4.1. Naming Conventions
*   **Компоненты**: `PascalCase` (e.g., `Button.tsx`, `UserProfile.tsx`).
*   **Хуки**: `camelCase` с префиксом `use` (e.g., `useAuth.ts`).
*   **Утилиты/Функции**: `camelCase` (e.g., `formatDate.ts`).
*   **Папки в `app`**: `kebab-case` (next.js convention).

### 4.2. TypeScript
*   Всегда описывайте `interface` для Props.
*   Избегайте `FC<Props>`, предпочитайте явное деструктурирование:
    ```tsx
    // Good
    export function MyComponent({ title, isActive }: MyComponentProps) { ... }
    ```

### 4.3. Стилизация (Tailwind CSS)
*   Используйте `cn()` утилиту (clsx + tailwind-merge) для условных классов.
*   Придерживайтесь токенов дизайн-системы (цвета `background`, `foreground`, `primary` и т.д.), не хардкодьте hex-цвета.

### 4.4. Обработка ошибок
*   Используйте `error.tsx` для перехвата ошибок рендеринга (Error Boundary).
*   Для ошибок API показывайте `toast` (Sonner/Toast).
*   Валидируйте формы с помощью **Zod** + **React Hook Form**.

---

## 5. Тестирование

*   **E2E**: Playwright. Основной упор на пользовательские сценарии (Happy Path).
*   **Unit**: Vitest/Jest (для сложной логики утилит и хуков).

## 6. Чеклист добавления новой страницы

1.  [ ] Определить URL структуру (`/app/...`).
2.  [ ] Создать Server Component Page (`page.tsx`).
3.  [ ] Определить загрузку данных (Data Fetching).
4.  [ ] Создать необходимые Client Components (таблицы, формы).
5.  [ ] Реализовать синхронизацию фильтров с URL.
6.  [ ] Добавить обработку Loading (`loading.tsx`).
7.  [ ] Добавить обработку Error (`error.tsx`).
