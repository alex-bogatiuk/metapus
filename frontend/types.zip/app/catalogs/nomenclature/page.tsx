"use client"

import { useMemo } from "react"
import { useRouter } from "next/navigation"
import { Eye } from "lucide-react"
import { DataToolbar } from "@/components/shared/data-toolbar"
import { FilterSidebar } from "@/components/shared/filter-sidebar"
import { DataTable, Column } from "@/components/shared/data-table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useListSelection } from "@/hooks/useListSelection"
import { useUrlSort } from "@/hooks/useUrlSort"
import type { NomenclatureItem } from "@/types"

// ── Demo data ───────────────────────────────────────────────────────────

const nomenclatureItems: NomenclatureItem[] = [
  {
    id: "1",
    name: "Тестовая",
    stock: "102,000",
    unit: "шт",
    price: "--",
    sku: "",
    type: "Запас",
  },
  {
    id: "2",
    name: "Болт М6x30",
    stock: "5 000",
    unit: "шт",
    price: "2,50",
    sku: "BLT-0630",
    type: "Запас",
  },
  {
    id: "3",
    name: "Гайка М6",
    stock: "8 200",
    unit: "шт",
    price: "1,20",
    sku: "NUT-06",
    type: "Запас",
  },
  {
    id: "4",
    name: "Консультация техническая",
    stock: "--",
    unit: "час",
    price: "3 500,00",
    sku: "SRV-001",
    type: "Услуга",
  },
  {
    id: "5",
    name: "Краска акриловая белая 10л",
    stock: "340",
    unit: "шт",
    price: "1 250,00",
    sku: "PNT-WH10",
    type: "Запас",
  },
]

// ── Filters ─────────────────────────────────────────────────────────────

const nomenclatureFilters = [
  {
    key: "stock",
    label: "Остатки",
    type: "toggle" as const,
    options: [{ value: "all", label: "Все" }],
    defaultValue: "all",
  },
  {
    key: "prices",
    label: "Цены",
    type: "toggle" as const,
    options: [{ value: "retail", label: "Розничная цена" }],
    defaultValue: "retail",
  },
  {
    key: "priceRange",
    label: "Диапазон цен",
    type: "range" as const,
  },
  {
    key: "type",
    label: "Тип",
    type: "select" as const,
    options: [
      { value: "all", label: "Все" },
      { value: "stock", label: "Запас" },
      { value: "service", label: "Услуга" },
      { value: "work", label: "Работа" },
    ],
    defaultValue: "all",
  },
]

// ── Columns ─────────────────────────────────────────────────────────────

const columns: Column<NomenclatureItem>[] = [
  {
    key: "name",
    label: "Наименование",
    sortable: true,
    render: (item) => (
      <span className="font-medium text-foreground">{item.name}</span>
    ),
  },
  {
    key: "stock",
    label: "Остаток",
    align: "right",
    sortable: true,
    render: (item) => (
      <span className="font-mono text-xs text-foreground">{item.stock}</span>
    ),
  },
  {
    key: "unit",
    label: "Ед. изм",
    sortable: true,
    render: (item) => (
      <span className="text-muted-foreground">{item.unit}</span>
    ),
  },
  {
    key: "price",
    label: "Розничная цена",
    align: "right",
    sortable: true,
    render: (item) => (
      <span className="font-mono text-xs text-foreground">{item.price}</span>
    ),
  },
  {
    key: "sku",
    label: "Артикул",
    sortable: true,
    render: (item) => (
      <span className="font-mono text-xs text-muted-foreground">
        {item.sku || "--"}
      </span>
    ),
  },
  {
    key: "type",
    label: "Тип",
    sortable: true,
    render: (item) => (
      <Badge variant="secondary" className="text-[10px]">
        {item.type}
      </Badge>
    ),
  },
]

// ── Page ────────────────────────────────────────────────────────────────

export default function NomenclatureListPage() {
  const router = useRouter()

  const visibleIds = useMemo(
    () => nomenclatureItems.map((i) => i.id),
    []
  )

  const {
    selectedIds,
    isAllSelected,
    isIndeterminate,
    toggleItem,
    toggleAll,
  } = useListSelection(visibleIds)

  const { sortColumn, sortDirection, handleSort } = useUrlSort()

  return (
    <div className="flex h-full flex-col">


      <DataToolbar
        title="Номенклатура"
        onCreateHref="/catalogs/nomenclature/new"
        extraButtons={
          <Button variant="outline" size="sm">
            <Eye className="mr-1.5 h-3.5 w-3.5" />
            Показать остатки
          </Button>
        }
      />

      <div className="flex flex-1 overflow-hidden">
        <div className="flex-1 overflow-auto">
          <DataTable
            data={nomenclatureItems}
            columns={columns}
            selectedIds={selectedIds}
            isAllSelected={isAllSelected}
            isIndeterminate={isIndeterminate}
            onToggleAll={toggleAll}
            onToggleItem={toggleItem}
            sortColumn={sortColumn}
            sortDirection={sortDirection}
            onSort={handleSort}
            onRowDoubleClick={(item) =>
              router.push(`/catalogs/nomenclature/${item.id}`)
            }
          />
        </div>

        <FilterSidebar
          filters={nomenclatureFilters}
          showGroups
          showDetails
        />
      </div>
    </div>
  )
}
