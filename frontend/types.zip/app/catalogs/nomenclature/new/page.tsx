"use client"

import { useRouter } from "next/navigation"
import { FormToolbar } from "@/components/shared/form-toolbar"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function NewNomenclaturePage() {
  const router = useRouter()

  return (
    <div className="flex h-full flex-col">
      <FormToolbar
        title="Новая номенклатура"
        primaryAction={{
          label: "Записать и закрыть",
          variant: "success",
          onClick: () => router.push("/catalogs/nomenclature"),
        }}
        secondaryActions={[{ label: "Записать" }]}
        backHref="/catalogs/nomenclature"
        onClose={() => router.push("/catalogs/nomenclature")}
      />

      <div className="flex-1 overflow-auto p-4">
        <Tabs defaultValue="main">
          <TabsList>
            <TabsTrigger value="main">Главное</TabsTrigger>
            <TabsTrigger value="dimensions">Габариты и учет</TabsTrigger>
            <TabsTrigger value="additional">Дополнительно</TabsTrigger>
          </TabsList>

          <TabsContent value="main">
            <div className="mt-4 grid grid-cols-1 gap-6 lg:grid-cols-3">
              <div className="lg:col-span-1">
                <div className="flex aspect-square items-center justify-center rounded-lg border-2 border-dashed border-muted bg-muted/30">
                  <span className="text-sm text-muted-foreground">Добавить изображение</span>
                </div>
              </div>
              <div className="lg:col-span-2">
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="md:col-span-2">
                    <Label className="text-xs text-muted-foreground">Наименование</Label>
                    <Input className="mt-1" placeholder="Введите наименование" autoFocus />
                  </div>
                  <div className="md:col-span-2">
                    <Label className="text-xs text-muted-foreground">Наименование для печати</Label>
                    <Textarea rows={2} className="mt-1" />
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Категория</Label>
                    <Select defaultValue="none">
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">{"<Без категории>"}</SelectItem>
                        <SelectItem value="materials">Материалы</SelectItem>
                        <SelectItem value="goods">Товары</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Артикул</Label>
                    <Input className="mt-1" />
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Тип</Label>
                    <Select defaultValue="stock">
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="stock">Запас</SelectItem>
                        <SelectItem value="service">Услуга</SelectItem>
                        <SelectItem value="work">Работа</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Ед. изм. хранения</Label>
                    <Select defaultValue="pcs">
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pcs">шт</SelectItem>
                        <SelectItem value="kg">кг</SelectItem>
                        <SelectItem value="l">л</SelectItem>
                        <SelectItem value="m">м</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="md:col-span-2">
                    <Label className="text-xs text-muted-foreground">Описание</Label>
                    <Textarea rows={4} className="mt-1" placeholder="Описание номенклатуры..." />
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="dimensions">
            <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
              <div>
                <Label className="text-xs text-muted-foreground">Длина, мм</Label>
                <Input className="mt-1" type="number" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Ширина, мм</Label>
                <Input className="mt-1" type="number" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Высота, мм</Label>
                <Input className="mt-1" type="number" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Вес, кг</Label>
                <Input className="mt-1" type="number" />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="additional">
            <p className="mt-4 text-sm text-muted-foreground">Дополнительные реквизиты</p>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
