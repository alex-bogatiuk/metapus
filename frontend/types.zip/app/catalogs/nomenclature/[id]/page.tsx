"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { FormToolbar } from "@/components/shared/form-toolbar"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

const topNavItems = [
  "Основное",
  "Комплектации",
  "Штрихкоды",
  "Цены",
  "Документы",
  "Файлы",
  "Отчеты",
  "Аналоги",
]

export default function NomenclatureItemPage() {
  const router = useRouter()
  const [activeTopNav, setActiveTopNav] = useState("Основное")

  return (
    <div className="flex h-full flex-col">
      <FormToolbar
        title="Тестовая (Номенклатура)"
        primaryAction={{
          label: "Записать и закрыть",
          variant: "success",
          onClick: () => router.push("/catalogs/nomenclature"),
        }}
        secondaryActions={[
          { label: "Записать" },
          { label: "Продать" },
          { label: "Купить" },
        ]}
        backHref="/catalogs/nomenclature"
        onClose={() => router.push("/catalogs/nomenclature")}
      />

      {/* Top navigation links */}
      <div className="flex items-center gap-1 border-b bg-card px-4 py-1 overflow-x-auto">
        {topNavItems.map((item) => (
          <button
            key={item}
            onClick={() => setActiveTopNav(item)}
            className={`shrink-0 rounded-md px-2.5 py-1 text-xs font-medium transition-colors ${
              activeTopNav === item
                ? "bg-primary/10 text-primary"
                : "text-primary hover:bg-muted hover:text-foreground"
            }`}
          >
            {item}
          </button>
        ))}
      </div>

      {/* Main form content */}
      <div className="flex flex-1 overflow-auto">
        <div className="flex-1 overflow-auto p-4">
          <Tabs defaultValue="main">
            <TabsList>
              <TabsTrigger value="main">Главное</TabsTrigger>
              <TabsTrigger value="dimensions">Габариты и учет</TabsTrigger>
              <TabsTrigger value="procurement">Закупка и производство</TabsTrigger>
              <TabsTrigger value="marking">Маркировка и ФГИС</TabsTrigger>
              <TabsTrigger value="storage">Хранение</TabsTrigger>
              <TabsTrigger value="pricelist">Прайс-лист</TabsTrigger>
              <TabsTrigger value="analytics">Аналитика</TabsTrigger>
              <TabsTrigger value="additional">Дополнительно</TabsTrigger>
            </TabsList>

            <TabsContent value="main">
              <div className="mt-4 grid grid-cols-1 gap-6 lg:grid-cols-3">
                {/* Left column - Image placeholder */}
                <div className="lg:col-span-1">
                  <div className="flex aspect-square items-center justify-center rounded-lg border-2 border-dashed border-muted bg-muted/30">
                    <span className="text-sm text-muted-foreground">
                      Добавить изображение
                    </span>
                  </div>
                </div>

                {/* Right columns - Fields */}
                <div className="lg:col-span-2">
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div className="md:col-span-2">
                      <Label className="text-xs text-muted-foreground">
                        Наименование
                      </Label>
                      <Input defaultValue="Тестовая" className="mt-1" />
                    </div>

                    <div className="md:col-span-2">
                      <Label className="text-xs text-muted-foreground">
                        Наименование для печати
                      </Label>
                      <Textarea
                        defaultValue="Тестовая"
                        rows={2}
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label className="text-xs text-muted-foreground">
                        Категория
                      </Label>
                      <Select defaultValue="none">
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">
                            {"<Без категории>"}
                          </SelectItem>
                          <SelectItem value="materials">Материалы</SelectItem>
                          <SelectItem value="goods">Товары</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-xs text-muted-foreground">
                        Артикул
                      </Label>
                      <Input className="mt-1" />
                    </div>

                    <div>
                      <Label className="text-xs text-muted-foreground">
                        Тип
                      </Label>
                      <Select defaultValue="stock">
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="stock">Запас</SelectItem>
                          <SelectItem value="service">Услуга</SelectItem>
                          <SelectItem value="work">Работа</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-xs text-muted-foreground">
                        Код
                      </Label>
                      <Input
                        defaultValue="00-00000001"
                        className="mt-1 font-mono"
                        readOnly
                      />
                    </div>

                    <div>
                      <Label className="text-xs text-muted-foreground">
                        Входит в группу
                      </Label>
                      <Select>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Выберите группу" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="root">Корень</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-xs text-muted-foreground">
                        Ед. изм. хранения
                      </Label>
                      <Select defaultValue="pcs">
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pcs">шт</SelectItem>
                          <SelectItem value="kg">кг</SelectItem>
                          <SelectItem value="l">л</SelectItem>
                          <SelectItem value="m">м</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center gap-2 md:col-span-2">
                      <Checkbox id="invalid" />
                      <Label htmlFor="invalid" className="text-sm">
                        Недействительна
                      </Label>
                    </div>

                    <div className="md:col-span-2">
                      <Label className="text-xs text-muted-foreground">
                        Описание
                      </Label>
                      <Textarea
                        rows={6}
                        className="mt-1"
                        placeholder="Описание номенклатуры..."
                      />
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="dimensions">
              <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Длина, мм</Label>
                  <Input className="mt-1" type="number" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Ширина, мм</Label>
                  <Input className="mt-1" type="number" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Высота, мм</Label>
                  <Input className="mt-1" type="number" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Вес, кг</Label>
                  <Input className="mt-1" type="number" />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="procurement">
              <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
                <div>
                  <Label className="text-xs text-muted-foreground">Основной поставщик</Label>
                  <Select>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Выберите поставщика" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="test">Тест</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Срок поставки, дней</Label>
                  <Input className="mt-1" type="number" />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="marking">
              <p className="mt-4 text-sm text-muted-foreground">Настройки маркировки и ФГИС</p>
            </TabsContent>

            <TabsContent value="storage">
              <p className="mt-4 text-sm text-muted-foreground">Настройки хранения</p>
            </TabsContent>

            <TabsContent value="pricelist">
              <p className="mt-4 text-sm text-muted-foreground">Настройки прайс-листа</p>
            </TabsContent>

            <TabsContent value="analytics">
              <p className="mt-4 text-sm text-muted-foreground">Аналитические данные</p>
            </TabsContent>

            <TabsContent value="additional">
              <p className="mt-4 text-sm text-muted-foreground">Дополнительные реквизиты</p>
            </TabsContent>
          </Tabs>
        </div>

        {/* Prices sidebar */}
        <div className="w-64 shrink-0 border-l bg-card p-4">
          <h3 className="text-sm font-semibold text-primary">Цены</h3>
          <Button variant="outline" size="sm" className="mt-3">
            Добавить
          </Button>
          <p className="mt-4 text-center text-sm text-muted-foreground">
            Цены не установлены
          </p>
        </div>
      </div>
    </div>
  )
}
