"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowUp,
  ArrowDown,
  Plus,
  Copy,
  Trash2,
  ClipboardPaste,
} from "lucide-react"
import { FormToolbar } from "@/components/shared/form-toolbar"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import type { GoodsReceiptLineItem } from "@/types"

export default function NewGoodsReceiptPage() {
  const router = useRouter()
  const [lines, setLines] = useState<GoodsReceiptLineItem[]>([])

  const addLine = () => {
    const newId = lines.length > 0 ? Math.max(...lines.map((l) => l.id)) + 1 : 1
    setLines([
      ...lines,
      {
        id: newId,
        nomenclature: "",
        quantity: "",
        price: "",
        discount: "",
        amount: "",
        vatRate: "22%",
        vatAmount: "",
        total: "",
        comment: "",
      },
    ])
  }

  const removeLine = (id: number) => {
    setLines(lines.filter((l) => l.id !== id))
  }

  return (
    <div className="flex h-full flex-col">
      <FormToolbar
        title="Приходная накладная (создание)"
        primaryAction={{
          label: "Провести и закрыть",
          variant: "success",
          onClick: () => router.push("/purchases/goods-receipts"),
        }}
        secondaryActions={[
          { label: "Записать" },
          { label: "Провести" },
        ]}
        backHref="/purchases/goods-receipts"
        onClose={() => router.push("/purchases/goods-receipts")}
      />

      <div className="flex items-center gap-1 border-b bg-card px-4 py-1 overflow-x-auto">
        {["Основное", "События", "Файлы", "Отчеты"].map((item) => (
          <button
            key={item}
            className="shrink-0 rounded-md px-2.5 py-1 text-xs font-medium text-primary hover:bg-muted hover:text-foreground transition-colors"
          >
            {item}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-auto">
        <div className="border-b bg-card p-4">
          <div className="grid grid-cols-1 gap-x-6 gap-y-3 md:grid-cols-2 lg:grid-cols-3">
            <div>
              <Label className="text-xs text-muted-foreground">Поставщик</Label>
              <Select>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Выберите поставщика" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="test">Тест</SelectItem>
                  <SelectItem value="supplier">ООО Поставщик</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Номер</Label>
              <div className="mt-1 flex items-center gap-2">
                <Input defaultValue="<Авто>" className="flex-1" readOnly />
                <Label className="shrink-0 text-xs text-muted-foreground">от:</Label>
                <Input type="text" defaultValue="12.02.2026" className="w-32" />
              </div>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Операция</Label>
              <Select defaultValue="receipt">
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="receipt">Поступление от поставщика</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Договор</Label>
              <Input className="mt-1" placeholder="Основной договор" />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Склад</Label>
              <Select defaultValue="main">
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="main">Основной склад</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <div className="flex flex-col">
          <Tabs defaultValue="goods">
            <div className="flex items-center border-b bg-card px-4">
              <TabsList className="h-9">
                <TabsTrigger value="goods" className="text-xs">
                  Товары ({lines.length})
                </TabsTrigger>
                <TabsTrigger value="services" className="text-xs">Услуги</TabsTrigger>
                <TabsTrigger value="payment" className="text-xs">Оплата</TabsTrigger>
                <TabsTrigger value="additional" className="text-xs">Дополнительно</TabsTrigger>
              </TabsList>
              <div className="ml-4 flex items-center gap-1">
                <Button variant="outline" size="sm" onClick={addLine}>
                  <Plus className="mr-1 h-3 w-3" />
                  Добавить
                </Button>
                <Button variant="outline" size="sm">Подобрать</Button>
              </div>
            </div>

            <TabsContent value="goods" className="mt-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/70">
                      <th className="w-8 px-2 py-2"><Checkbox /></th>
                      <th className="w-10 px-2 py-2 text-center text-xs font-medium text-muted-foreground">N</th>
                      <th className="min-w-[200px] px-3 py-2 text-left text-xs font-medium text-muted-foreground">Номенклатура</th>
                      <th className="w-24 px-3 py-2 text-right text-xs font-medium text-muted-foreground">Количество</th>
                      <th className="w-24 px-3 py-2 text-right text-xs font-medium text-muted-foreground">Цена</th>
                      <th className="w-24 px-3 py-2 text-right text-xs font-medium text-muted-foreground">Сумма</th>
                      <th className="w-16 px-3 py-2 text-center text-xs font-medium text-muted-foreground">% НДС</th>
                      <th className="w-24 px-3 py-2 text-right text-xs font-medium text-muted-foreground">Всего</th>
                      <th className="w-8" />
                    </tr>
                  </thead>
                  <tbody>
                    {lines.length === 0 && (
                      <tr>
                        <td colSpan={9} className="px-4 py-8 text-center text-sm text-muted-foreground">
                          Нажмите &quot;Добавить&quot; для добавления строки
                        </td>
                      </tr>
                    )}
                    {lines.map((line, idx) => (
                      <tr key={line.id} className="border-b hover:bg-muted/30 transition-colors">
                        <td className="px-2 py-1.5"><Checkbox /></td>
                        <td className="px-2 py-1.5 text-center text-xs text-muted-foreground">{idx + 1}</td>
                        <td className="px-1 py-1"><Input className="h-7 text-xs" placeholder="Выберите номенклатуру" /></td>
                        <td className="px-1 py-1"><Input className="h-7 text-right font-mono text-xs" /></td>
                        <td className="px-1 py-1"><Input className="h-7 text-right font-mono text-xs" /></td>
                        <td className="px-1 py-1"><Input className="h-7 text-right font-mono text-xs" readOnly /></td>
                        <td className="px-1 py-1 text-center text-xs text-muted-foreground">{line.vatRate}</td>
                        <td className="px-1 py-1"><Input className="h-7 text-right font-mono text-xs" readOnly /></td>
                        <td className="px-1 py-1">
                          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => removeLine(line.id)}>
                            <Trash2 className="h-3 w-3 text-destructive" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            <TabsContent value="services" className="p-4">
              <p className="text-sm text-muted-foreground">Нет добавленных услуг</p>
            </TabsContent>
            <TabsContent value="payment" className="p-4">
              <p className="text-sm text-muted-foreground">Настройки оплаты</p>
            </TabsContent>
            <TabsContent value="additional" className="p-4">
              <p className="text-sm text-muted-foreground">Дополнительные сведения</p>
            </TabsContent>
          </Tabs>
        </div>

        <div className="border-t bg-card px-4 py-3">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-xs text-muted-foreground">Комментарий</Label>
              <Textarea className="mt-1 w-80" rows={2} />
            </div>
            <div className="flex items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">НДС:</span>
                <span className="font-mono font-medium text-foreground">0,00</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium text-foreground">Всего:</span>
                <span className="text-lg font-semibold text-foreground">0,00</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
