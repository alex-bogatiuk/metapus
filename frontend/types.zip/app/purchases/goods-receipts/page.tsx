"use client"

import { useMemo } from "react"
import { useRouter } from "next/navigation"
import { CircleCheck, Circle } from "lucide-react"
import { DataToolbar } from "@/components/shared/data-toolbar"
import { FilterSidebar } from "@/components/shared/filter-sidebar"
import { DataTable, Column } from "@/components/shared/data-table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useListSelection } from "@/hooks/useListSelection"
import { useUrlSort } from "@/hooks/useUrlSort"
import type { GoodsReceiptDoc } from "@/types"

// ── Demo data ───────────────────────────────────────────────────────────

const documents: GoodsReceiptDoc[] = [
  {
    id: "1",
    status: "posted",
    date: "06.02.2026",
    number: "НФ00-000001",
    counterparty: "Тест",
    amount: "11,00",
    warehouse: "Основной склад",
    operation: "Поступление от поставщика",
  },
  {
    id: "2",
    status: "posted",
    date: "12.02.2026",
    number: "НФ00-000002",
    counterparty: "Тест",
    amount: "110,00",
    warehouse: "Основной склад",
    operation: "Поступление от поставщика",
  },
  {
    id: "3",
    status: "draft",
    date: "12.02.2026",
    number: "НФ00-000003",
    counterparty: "ООО Склад-Сервис",
    amount: "250,00",
    warehouse: "Основной склад",
    operation: "Поступление от поставщика",
  },
]

// ── Filters ─────────────────────────────────────────────────────────────

const docFilters = [
  {
    key: "period",
    label: "Период",
    type: "text" as const,
  },
  {
    key: "counterparty",
    label: "Поставщик, ИНН, телефон",
    type: "text" as const,
  },
  {
    key: "warehouse",
    label: "Склад",
    type: "select" as const,
    options: [
      { value: "all", label: "Все" },
      { value: "main", label: "Основной склад" },
    ],
    defaultValue: "all",
  },
  {
    key: "operation",
    label: "Операция",
    type: "select" as const,
    options: [
      { value: "all", label: "Все" },
      { value: "receipt", label: "Поступление от поставщика" },
    ],
    defaultValue: "all",
  },
]

// ── Columns ─────────────────────────────────────────────────────────────

const columns: Column<GoodsReceiptDoc>[] = [
  {
    key: "date",
    label: "Дата",
    sortable: true,
    render: (doc) => (
      <span className="text-muted-foreground">{doc.date}</span>
    ),
  },
  {
    key: "number",
    label: "Номер",
    sortable: true,
    render: (doc) => (
      <span className="font-mono text-xs font-medium text-foreground">
        {doc.number}
      </span>
    ),
  },
  {
    key: "counterparty",
    label: "Поставщик / Покупатель",
    sortable: true,
    render: (doc) => (
      <span className="text-foreground">{doc.counterparty}</span>
    ),
  },
  {
    key: "amount",
    label: "Сумма",
    align: "right",
    sortable: true,
    render: (doc) => (
      <span className="font-mono text-xs text-foreground">{doc.amount}</span>
    ),
  },
  {
    key: "warehouse",
    label: "Склад",
    sortable: true,
    render: (doc) => (
      <span className="text-muted-foreground">{doc.warehouse}</span>
    ),
  },
  {
    key: "operation",
    label: "Операция",
    sortable: true,
    render: (doc) => (
      <span className="text-muted-foreground">{doc.operation}</span>
    ),
  },
]

// ── Page ────────────────────────────────────────────────────────────────

export default function GoodsReceiptsListPage() {
  const router = useRouter()

  const visibleIds = useMemo(
    () => documents.map((d) => d.id),
    []
  )

  const {
    selectedIds,
    isAllSelected,
    isIndeterminate,
    toggleItem,
    toggleAll,
  } = useListSelection(visibleIds)

  const { sortColumn, sortDirection, handleSort } = useUrlSort()

  return (
    <div className="flex h-full flex-col">


      <div className="border-b bg-card px-4 py-1">
        <Tabs defaultValue="receipts">
          <TabsList className="h-8">
            <TabsTrigger value="receipts" className="text-xs">
              Приходные накладные
            </TabsTrigger>
            <TabsTrigger value="orders" className="text-xs">
              Заказы поставщикам (к поступлению)
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <DataToolbar
        title="Приходные накладные"
        onCreateHref="/purchases/goods-receipts/new"
        extraButtons={
          <Button variant="outline" size="sm">
            Создать на основании
          </Button>
        }
      />

      <div className="flex flex-1 overflow-hidden">
        <div className="flex-1 overflow-auto">
          <DataTable
            data={documents}
            columns={columns}
            selectedIds={selectedIds}
            isAllSelected={isAllSelected}
            isIndeterminate={isIndeterminate}
            onToggleAll={toggleAll}
            onToggleItem={toggleItem}
            sortColumn={sortColumn}
            sortDirection={sortDirection}
            onSort={handleSort}
            onRowDoubleClick={(doc) =>
              router.push(`/purchases/goods-receipts/${doc.id}`)
            }
            renderPrefix={(doc) =>
              doc.status === "posted" ? (
                <CircleCheck className="h-4 w-4 text-success" />
              ) : (
                <Circle className="h-4 w-4 text-muted-foreground" />
              )
            }
          />
        </div>

        <FilterSidebar
          filters={docFilters}
          showGroups={false}
          showDetails
        />
      </div>
    </div>
  )
}
