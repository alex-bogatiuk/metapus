"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Filter, FolderOpen, FileText, PanelRightClose, PanelRightOpen } from "lucide-react"
import { cn } from "@/lib/utils"

interface FilterConfig {
  key: string
  label: string
  type: "select" | "toggle" | "text" | "range"
  options?: { value: string; label: string }[]
  defaultValue?: string
}

interface FilterSidebarProps {
  filters?: FilterConfig[]
  showGroups?: boolean
  showDetails?: boolean
}

const STORAGE_KEY = "metapus-filter-sidebar-collapsed"

export function FilterSidebar({
  filters = [],
  showGroups = true,
  showDetails = true,
}: FilterSidebarProps) {
  const [activeFilters, setActiveFilters] = useState<Record<string, boolean>>({})
  const [isCollapsed, setIsCollapsed] = useState(true)

  // Persist collapse state in localStorage
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored !== null) {
      setIsCollapsed(stored === "true")
    }
  }, [])

  const toggleCollapse = () => {
    const next = !isCollapsed
    setIsCollapsed(next)
    localStorage.setItem(STORAGE_KEY, String(next))
  }

  return (
    <div
      className={cn(
        "flex flex-col shrink-0 border-l bg-card transition-all duration-300 ease-in-out overflow-hidden",
        isCollapsed ? "w-9" : "w-72"
      )}
    >
      {/* Content — hidden when collapsed */}
      <div
        className={cn(
          "flex-1 transition-opacity duration-200",
          isCollapsed ? "opacity-0 pointer-events-none" : "opacity-100"
        )}
      >
        <Tabs defaultValue="filters">
          <TabsList className="mx-2 mt-2 w-auto">
            {showGroups && (
              <TabsTrigger value="groups" className="gap-1.5 text-xs">
                <FolderOpen className="h-3.5 w-3.5" />
                Группы
              </TabsTrigger>
            )}
            <TabsTrigger value="filters" className="gap-1.5 text-xs">
              <Filter className="h-3.5 w-3.5" />
              Фильтры
            </TabsTrigger>
            {showDetails && (
              <TabsTrigger value="details" className="gap-1.5 text-xs">
                <FileText className="h-3.5 w-3.5" />
                Детали
              </TabsTrigger>
            )}
          </TabsList>

          {showGroups && (
            <TabsContent value="groups" className="p-3">
              <div className="rounded-md border p-3 text-center text-sm text-muted-foreground">
                Все элементы
              </div>
            </TabsContent>
          )}

          <TabsContent value="filters" className="p-3">
            <div className="flex flex-col gap-3">
              {filters.map((f) => (
                <div key={f.key} className="flex flex-col gap-1.5">
                  {f.type === "toggle" && (
                    <div className="flex items-center justify-between">
                      <Switch
                        checked={activeFilters[f.key] ?? false}
                        onCheckedChange={(v) =>
                          setActiveFilters((s) => ({ ...s, [f.key]: v }))
                        }
                      />
                      <Label className="text-xs">{f.label}</Label>
                      {f.options && (
                        <Select defaultValue={f.defaultValue}>
                          <SelectTrigger className="h-7 w-24 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {f.options.map((o) => (
                              <SelectItem key={o.value} value={o.value}>
                                {o.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                  )}
                  {f.type === "select" && (
                    <div>
                      <Label className="mb-1 text-xs text-muted-foreground">
                        {f.label}
                      </Label>
                      <Select defaultValue={f.defaultValue}>
                        <SelectTrigger className="h-8 text-xs">
                          <SelectValue placeholder={f.label} />
                        </SelectTrigger>
                        <SelectContent>
                          {f.options?.map((o) => (
                            <SelectItem key={o.value} value={o.value}>
                              {o.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  {f.type === "text" && (
                    <div>
                      <Label className="mb-1 text-xs text-muted-foreground">
                        {f.label}
                      </Label>
                      <Input
                        className="h-8 text-xs"
                        placeholder={f.label}
                      />
                    </div>
                  )}
                  {f.type === "range" && (
                    <div>
                      <Label className="mb-1 text-xs text-muted-foreground">
                        {f.label}
                      </Label>
                      <div className="flex items-center gap-2">
                        <Input className="h-7 text-xs" placeholder="От" />
                        <span className="text-xs text-muted-foreground">-</span>
                        <Input className="h-7 text-xs" placeholder="до" />
                      </div>
                    </div>
                  )}
                </div>
              ))}
              <Button variant="outline" size="sm" className="mt-2 text-xs">
                <Filter className="mr-1.5 h-3 w-3" />
                Добавить
              </Button>
            </div>
          </TabsContent>

          {showDetails && (
            <TabsContent value="details" className="p-3">
              <p className="text-sm text-muted-foreground">
                Выберите элемент для просмотра деталей
              </p>
            </TabsContent>
          )}
        </Tabs>
      </div>

      {/* Toggle button — moved to bottom */}
      <div
        className={cn(
          "flex items-center border-t h-9 mt-auto",
          isCollapsed ? "justify-center" : "justify-end px-2"
        )}
      >
        <TooltipProvider delayDuration={300}>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 shrink-0"
                onClick={toggleCollapse}
              >
                {isCollapsed ? (
                  <PanelRightOpen className="h-4 w-4" />
                ) : (
                  <PanelRightClose className="h-4 w-4" />
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="left">
              {isCollapsed ? "Показать панель" : "Скрыть панель"}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </div>
  )
}
