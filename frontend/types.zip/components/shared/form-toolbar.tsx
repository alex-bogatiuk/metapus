"use client"

import Link from "next/link"
import { ArrowLeft, ArrowRight, MoreHorizontal, HelpCircle, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface FormToolbarProps {
  title: string
  primaryAction: {
    label: string
    variant?: "default" | "success"
    onClick?: () => void
  }
  secondaryActions?: {
    label: string
    onClick?: () => void
  }[]
  backHref?: string
  onClose?: () => void
}

export function FormToolbar({
  title,
  primaryAction,
  secondaryActions = [],
  backHref,
  onClose,
}: FormToolbarProps) {
  return (
    <div className="border-b bg-card">
      <div className="flex items-center gap-2 px-4 py-2">
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7" asChild={!!backHref}>
            {backHref ? (
              <Link href={backHref}>
                <ArrowLeft className="h-3.5 w-3.5" />
              </Link>
            ) : (
              <ArrowLeft className="h-3.5 w-3.5" />
            )}
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7">
            <ArrowRight className="h-3.5 w-3.5" />
          </Button>
        </div>

        <h1 className="mr-4 text-sm font-semibold text-foreground">{title}</h1>

        <div className="flex flex-1 items-center gap-2">
          <Button
            size="sm"
            variant={primaryAction.variant === "success" ? "success" : "default"}
            onClick={primaryAction.onClick}
          >
            {primaryAction.label}
          </Button>

          {secondaryActions.map((action, i) => (
            <Button
              key={i}
              variant="outline"
              size="sm"
              onClick={action.onClick}
            >
              {action.label}
            </Button>
          ))}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="ml-auto">
                Еще
                <MoreHorizontal className="ml-1.5 h-3.5 w-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Скопировать</DropdownMenuItem>
              <DropdownMenuItem>Пометить на удаление</DropdownMenuItem>
              <DropdownMenuItem>История изменений</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button variant="ghost" size="icon" className="h-7 w-7">
            <HelpCircle className="h-3.5 w-3.5" />
          </Button>
        </div>

        {onClose && (
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={onClose}
          >
            <X className="h-3.5 w-3.5" />
          </Button>
        )}
      </div>
    </div>
  )
}
