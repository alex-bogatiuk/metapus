import { useEffect, useCallback, useRef } from "react"
import { usePathname } from "next/navigation"
import { useTabsStore } from "@/stores/useTabsStore"

/**
 * Hook to register a form/page as "dirty" (having unsaved changes).
 *
 * Usage in a form component:
 * ```tsx
 * const { markDirty, markClean } = useTabDirty()
 *
 * // Call markDirty() when form values change
 * // Call markClean() after successful save
 * ```
 */
export function useTabDirty() {
    const pathname = usePathname()
    const { setDirty, tabs } = useTabsStore()

    // Find the tab that matches the current pathname
    const currentTab = tabs.find((t) => t.url === pathname)
    const tabId = currentTab?.id

    const markDirty = useCallback(() => {
        if (tabId) {
            setDirty(tabId, true)
        }
    }, [tabId, setDirty])

    const markClean = useCallback(() => {
        if (tabId) {
            setDirty(tabId, false)
        }
    }, [tabId, setDirty])

    // Clean up dirty state when unmounting
    useEffect(() => {
        return () => {
            if (tabId) {
                setDirty(tabId, false)
            }
        }
    }, [tabId, setDirty])

    return { markDirty, markClean, isDirty: currentTab?.isDirty ?? false }
}
