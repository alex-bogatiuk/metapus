/**
 * API Client – single point of contact for the backend REST API.
 *
 * All fetch calls go through `apiFetch()` which:
 *  - Prepends the base URL
 *  - Attaches auth headers (TODO)
 *  - Handles JSON parsing
 *  - Throws typed errors
 *
 * Usage:
 *   import { api } from "@/lib/api"
 *   const items = await api.nomenclature.list()
 */

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8080/api"

// ── Generic fetcher ─────────────────────────────────────────────────────

export class ApiError extends Error {
    constructor(
        public status: number,
        public statusText: string,
        public body?: unknown
    ) {
        super(`API ${status}: ${statusText}`)
        this.name = "ApiError"
    }
}

async function apiFetch<T>(
    path: string,
    options?: RequestInit
): Promise<T> {
    const res = await fetch(`${API_BASE}${path}`, {
        headers: {
            "Content-Type": "application/json",
            // TODO: attach Authorization header
            ...options?.headers,
        },
        ...options,
    })

    if (!res.ok) {
        const body = await res.text().catch(() => undefined)
        throw new ApiError(res.status, res.statusText, body)
    }

    return res.json() as Promise<T>
}

// ── Resource endpoints ──────────────────────────────────────────────────

// Extend this object as new resources are added.
export const api = {
    nomenclature: {
        list: () =>
            apiFetch<unknown[]>("/catalogs/nomenclature"),
        get: (id: string) =>
            apiFetch<unknown>(`/catalogs/nomenclature/${id}`),
        create: (data: unknown) =>
            apiFetch<unknown>("/catalogs/nomenclature", {
                method: "POST",
                body: JSON.stringify(data),
            }),
    },

    goodsReceipts: {
        list: () =>
            apiFetch<unknown[]>("/purchases/goods-receipts"),
        get: (id: string) =>
            apiFetch<unknown>(`/purchases/goods-receipts/${id}`),
        create: (data: unknown) =>
            apiFetch<unknown>("/purchases/goods-receipts", {
                method: "POST",
                body: JSON.stringify(data),
            }),
        post: (id: string) =>
            apiFetch<unknown>(`/purchases/goods-receipts/${id}/post`, {
                method: "POST",
            }),
    },
} as const
